/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import controller.CadastroUsuarioCTRL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CadastroUsuario;

/**
 *
 * @author Usuario
 */

@WebServlet(name = "CadastroUsuario", urlPatterns = {"/CadastroUsuarioServlet"})
public class CadastroUsuarioServlet extends HttpServlet {

 
    //public String nome, curso, email, senha, classe, telefone, dataNascimento, semestre;
    public String pagina = null;
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
     
        CadastroUsuario CadUser = new CadastroUsuario();
        CadUser.setNome(request.getParameter("nome"));
        CadUser.setCurso(request.getParameter("curso"));
        CadUser.setEmail(request.getParameter("email"));
        CadUser.setSenha(request.getParameter("senha"));
        CadUser.setClasse(request.getParameter("classe"));
        CadUser.setTelefone(request.getParameter("telefone"));
        CadUser.setDataNascimento(request.getParameter("dataNascimento"));
        CadUser.setSemenstre(request.getParameter("semestre"));
        CadastroUsuarioCTRL.Insert(CadUser);
        
         pagina = "index.html";
         response.sendRedirect(pagina);

    }
  @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
            System.out.println(request.getParameter("CadastroUsuario"));
        
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
