/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Connecta.Connecta;
import java.sql.*;
import model.Login;


/**
 *
 * @author Usuario
 */
public class LoginDAO {

    private ResultSet rs;
    PreparedStatement ps ;
    private String SQL, msg;
    private Connecta Connecta;
    

    public LoginDAO() {

        this.Connecta = new Connecta();

    }

    public boolean select(Login Userlogin) throws SQLException {
       
       SQL = "SELECT usuario, senha, classe FROM usuario WHERE usuario=? AND senha=?";
      
        try {
            Connecta.conecta();
            ps = Connecta.getCon().prepareStatement(SQL);
           // rs = ps.executeQuery();

            ps.setString(1, Userlogin.getUsuario());
            ps.setString(2, Userlogin.getSenha());
            ps.setString(3, Userlogin.getClasse());
            ps.setString(4, Userlogin.getUsuario());
            ps.setString(4, Userlogin.getSenha());
            ps.execute();
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } finally {
            
            ps.close();
            rs.close();
            Connecta.desconecta();
        }
    }
}
