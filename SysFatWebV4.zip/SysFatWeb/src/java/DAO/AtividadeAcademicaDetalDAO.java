
package DAO;
import Connecta.Connecta;
import java.sql.*;
import java.util.ArrayList;
import model.AtividadeAcademicaDetalhe;


public class AtividadeAcademicaDetalDAO {
    
    public Connecta connecta;
    private ResultSet rs;
    private String SQL, msg;

    public AtividadeAcademicaDetalDAO(){
        
         this.connecta = new Connecta();
    }
    
    public ResultSet select() {

        SQL = "select * from atividade_academica_detalhe where id_atividade_academica = ?";

        try{
           connecta.conecta();
           PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
           rs = ps.executeQuery();

            ArrayList<AtividadeAcademicaDetalhe> Atvdete = new ArrayList<AtividadeAcademicaDetalhe>();
            
            while (rs.next()){
                
                AtividadeAcademicaDetalhe AtvDet = new AtividadeAcademicaDetalhe();
                AtvDet.setId(rs.getInt("id"));
                AtvDet.setIdAdividadeAcademica(rs.getInt("id_atividade_academica"));
                AtvDet.setCampoDinamico(rs.getString("campo"));
           }
            
             ps.close();
            connecta.desconecta();
            return (ResultSet) Atvdete;
        }catch (SQLException ex){
            System.err.println("Erro ao tentar executar a consulta" + ex.getMessage());
            
        }
        return rs;
        
    }
    public void Insert(AtividadeAcademicaDetalhe AtvDet){
       
        SQL = "insert into atividade_academica_detalhe\n" +
              " (id_atividade_academica, campo) values (?, ?)";
        
        try{
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
       
            ps.setInt(1, AtvDet.getIdAdividadeAcademica());
            ps.setString(2, AtvDet.getCampoDinamico());
            
            ps.execute();
            ps.close();
            connecta.desconecta();
          } catch (SQLException ex) {
            throw new RuntimeException(ex);
         }  
        
    }     
    public ResultSet Update(AtividadeAcademicaDetalhe Upatvdetal) {

        SQL = "Update atividade_academica_detalhe set id_atividade_academica = ?, campo = ? where id = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
            
           
            ps.setInt(1, Upatvdetal.getIdAdividadeAcademica());
            ps.setString(2, Upatvdetal.getCampoDinamico());
            ps.setInt(3, Upatvdetal.getId());
            
            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } return rs;
    }
    
    
        public ResultSet Delete(AtividadeAcademicaDetalhe Dlatvi){
        
        SQL = "delete from atividade_academica_detalhe where id = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
            
            ps.setInt(1, Dlatvi.getId());
            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }
        
}
