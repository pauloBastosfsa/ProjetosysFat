/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author paulo
 */
public class AtividadeAcademicaAnexo {
    
    private Integer id, idAtividadeAcademica;
    private String anexoFoto, status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdAtividadeAcademica() {
        return idAtividadeAcademica;
    }

    public void setIdAtividadeAcademica(Integer idAtividadeAcademica) {
        this.idAtividadeAcademica = idAtividadeAcademica;
    }

    public String getAnexoFoto() {
        return anexoFoto;
    }

    public void setAnexoFoto(String anexoFoto) {
        this.anexoFoto = anexoFoto;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AtividadeAcademicaAnexo(Integer id, Integer idAtividadeAcademica, String anexoFoto, String status) {
        this.id = id;
        this.idAtividadeAcademica = idAtividadeAcademica;
        this.anexoFoto = anexoFoto;
        this.status = status;
    }
    
    
    
}
