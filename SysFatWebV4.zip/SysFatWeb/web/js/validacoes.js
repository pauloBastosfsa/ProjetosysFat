

$("#form-login").submit(function(){

		var login = $("#input-login").val();

		var senha = $("#input-senha").val();

		if(login == ""  || senha == "" || senha.length <5 || login.length <7 ){


		var texto_feedback = "É necessario inserir usuário e senha válidos!";

			

			document.getElementById("alerts").style.display = "block";
	

					$("#alerts").text(texto_feedback);
			          $("#alerts").addClass("animated slideInUp");


			
			return false;

		}
	
	    

})





$("#form-recuperar-senha").submit(function(){

		var login = $("#input-celular-email").val();


		if(login == ""  || login.length <7 ){
			

			var texto_feedback = "É necessario inserir e-mail ou celular válido";

			

			document.getElementById("alerts").style.display = "block";
	

					$("#alerts").text(texto_feedback);
			          $("#alerts").addClass("animated slideInUp");



			return false;
		}


	

	    

})
