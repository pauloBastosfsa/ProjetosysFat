package DAO;

import java.sql.*;
import java.util.ArrayList;
import model.AtividadeAcademica;
import Connecta.Connecta;
import model.CadastroUsuario;

public class AtividadeAcademicaDAO {

    private ResultSet rs;
    private String SQL, msg;
    private final Connecta Connecta;

    public AtividadeAcademicaDAO() {

        this.Connecta = new Connecta();

    }

    public ResultSet select() {

        SQL = "select * from atividade_academica";

        try {
            Connecta.conecta();
            PreparedStatement ps = Connecta.getCon().prepareStatement(SQL);
            rs = ps.executeQuery();

            ArrayList<AtividadeAcademica> listAtividade = new ArrayList<AtividadeAcademica>();

            while (rs.next()) {
                AtividadeAcademica atvAcd = new AtividadeAcademica(SQL, SQL, SQL, SQL);
                atvAcd.setId(rs.getInt("id"));
                atvAcd.setTipoAtividade(rs.getString("tipo_atividade"));
                atvAcd.setDescricao(rs.getString("descricao"));
                atvAcd.setAnexo(rs.getString("anexo"));
                atvAcd.setDataEvento(rs.getString(""));
                listAtividade.add(atvAcd);

            }
            ps.close();
            Connecta.desconecta();
            return (ResultSet) listAtividade;
        } catch (SQLException ex) {
            System.err.println("Erro ao tentar executar a consulta" + ex.getMessage());

        }
        return rs;

    }

    public void Insert(AtividadeAcademica atvAc) {

        SQL = "insert into atividade_academica(tipo_atividade, descricao, anexo, data_evento) values(?, ?, ?, ?)";

        try {
            Connecta.conecta();
            PreparedStatement ps = Connecta.getCon().prepareStatement(SQL);

            ps.setString(1, atvAc.getTipoAtividade());
            ps.setString(2, atvAc.getDescricao());
            ps.setString(3, atvAc.getAnexo());
            ps.setString(4, atvAc.getDataEvento());

            ps.execute();
            ps.close();
            Connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

    }

    public ResultSet Update(AtividadeAcademica Upativ) {

        SQL = "Update atividade_academica set tipo_atividade = ?, descricao = ?, anexo = ?, data_Evento = ? where id = ?";

        try {
            Connecta.conecta();
            PreparedStatement ps = Connecta.getCon().prepareStatement(SQL);

            ps.setString(1, Upativ.getTipoAtividade());
            ps.setString(2, Upativ.getDescricao());
            ps.setString(3, Upativ.getAnexo());
            ps.setString(4, Upativ.getDataEvento());
            ps.setInt(5, Upativ.getId());

            ps.execute();
            ps.close();
            Connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }

    public ResultSet Delete(AtividadeAcademica Dlatvi) {

        SQL = "delete from atividade_academica where id = ?";

        try {
            Connecta.conecta();
            PreparedStatement ps = Connecta.getCon().prepareStatement(SQL);

            ps.setInt(1, Dlatvi.getId());

            ps.execute();
            ps.close();
            Connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }

}
