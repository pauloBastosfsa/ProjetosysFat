/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Connecta.Connecta;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Feedback;

/**
 *
 * @author paulo
 */
public class FeedbackDAO {

    public Connecta connecta;
    private ResultSet rs;
    private String SQL, msg;

    public FeedbackDAO() {

        this.connecta = new Connecta();
    }

    public ResultSet select() {

        SQL = "select * from feedbak where id_atividade = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
            rs = ps.executeQuery();

            ArrayList<Feedback> Listfeedback = new ArrayList<Feedback>();

            while (rs.next()) {

                Feedback feed = new Feedback();
                feed.setIdusuario(rs.getInt("id_Usuario"));
                feed.setIdAtividadeAcademica(rs.getInt("id_atividade"));
                feed.setFeedBack(rs.getString("feedback"));
                feed.setDataFeedBack(rs.getString("data_hora"));

            }

            ps.close();
            connecta.desconecta();
            return (ResultSet) Listfeedback;
        } catch (SQLException ex) {
            System.err.println("Erro ao tentar executar a consulta" + ex.getMessage());

        }
        return rs;

    }

    public void Insert(Feedback Cadfeedback) {

        SQL = "insert into feedback (id_usuario, Id_atividade, feedback) values (?, ?, ?)";
        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);

            ps.setInt(1, Cadfeedback.getIdusuario());
            ps.setInt(2, Cadfeedback.getIdAtividadeAcademica());
            ps.setString(3, Cadfeedback.getFeedBack());

            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

    }

    public ResultSet Delete(Feedback DelFeed) {
        SQL = "delete from feedback where id = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);

            ps.setInt(1, DelFeed.getId());
            ps.execute();
            ps.close();

            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }

}
