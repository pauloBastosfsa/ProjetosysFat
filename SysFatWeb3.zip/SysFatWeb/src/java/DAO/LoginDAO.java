/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Connecta.Connecta;
import java.sql.*;
import model.Login;


/**
 *
 * @author Usuario
 */
public class LoginDAO {

    private ResultSet rs;
    PreparedStatement ps ;
    private String SQL, msg;
    private Connecta Connecta;
    

    public LoginDAO() {

        this.Connecta = new Connecta();

    }

    public boolean select() throws SQLException {
       
       SQL = "SELECT usuario, senha, classe FROM usuario WHERE usuario=? AND senha=?";
      
        try {
            Connecta.conecta();
            ps = Connecta.getCon().prepareStatement(SQL);
            rs = ps.executeQuery();
            
            Login login = new Login(SQL, SQL, SQL);
            
            ps.setString(1, login.getUsuario());
            ps.setString(2, login.getSenha());
            ps.setString(3, login.getClasse());
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } finally {
            
            ps.close();
            rs.close();
            Connecta.desconecta();
        }
    }
}
