/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author paulo
 */
public class AtividadeAcademicaDetalhe {

   private Integer id, idAdividadeAcademica;
   private String campoDinamico;

    public AtividadeAcademicaDetalhe(Integer idAdividadeAcademica, String campoDinamico) {
        this.idAdividadeAcademica = idAdividadeAcademica;
        this.campoDinamico = campoDinamico;
    }

    public AtividadeAcademicaDetalhe() {
      
    }



   
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdAdividadeAcademica() {
        return idAdividadeAcademica;
    }

    public void setIdAdividadeAcademica(Integer idAdividadeAcademica) {
        this.idAdividadeAcademica = idAdividadeAcademica;
    }

    public String getCampoDinamico() {
        return campoDinamico;
    }

    public void setCampoDinamico(String campoDinamico) {
        this.campoDinamico = campoDinamico;
    }
   
   

}
