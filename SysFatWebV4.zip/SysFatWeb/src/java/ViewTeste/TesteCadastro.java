/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewTeste;


import DAO.CadastroUsuarioDAO;
import controller.AtividadeAcademicaDetalheCTRL;
import controller.AtividadeAdacemicCTRL;
import controller.CadastroUsuarioCTRL;
import controller.FeedbackCTRL;
import controller.LoginCTRL;
import java.util.List;
import model.CadastroUsuario;

/**
 *
 * @author Usuario
 */
public class TesteCadastro {

    public static void main(String[] args) {
      
   //  CadastroUsuarioCTRL.Insert();
     //CadastroUsuarioCTRL.Delete();
     //CadastroUsuarioCTRL.Update();
     //CadastroUsuarioCTRL.select();
     
   //  AtividadeAdacemicCTRL.Insert();
    // AtividadeAdacemicCTRL.Update();
    // AtividadeAdacemicCTRL.Delete();
    
    //AtividadeAcademicaDetalheCTRL.Insert();
    //AtividadeAcademicaDetalheCTRL.Update();
   // AtividadeAcademicaDetalheCTRL.Delete();
     
   // FeedbackCTRL.Insert();
    //FeedbackCTRL.Delete();
    
    //LoginCTRL.();
       
}

}
