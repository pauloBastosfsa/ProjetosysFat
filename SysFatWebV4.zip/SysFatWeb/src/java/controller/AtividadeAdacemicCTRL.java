/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AtividadeAcademicaDAO;
import java.sql.ResultSet;
import model.AtividadeAcademica;
import model.CadastroUsuario;

/**
 *
 * @author paulo
 */
public class AtividadeAdacemicCTRL {

    public static ResultSet Insert(AtividadeAcademica CadAtividade) {
        AtividadeAcademicaDAO CadAtividadeDAO = new AtividadeAcademicaDAO();
        CadAtividadeDAO.Insert(CadAtividade);
        return null;
    }

    public static ResultSet Update() {
        AtividadeAcademicaDAO UpAtividadeDAO = new AtividadeAcademicaDAO();
        AtividadeAcademica UpAtividade = new AtividadeAcademica();
        UpAtividade.setId(UpAtividade.getId());
        UpAtividadeDAO.Update(UpAtividade);
        return null;

    }
    
     public static ResultSet Delete() {
        AtividadeAcademicaDAO DelAtividadeDAO = new AtividadeAcademicaDAO();
        AtividadeAcademica DelAtividade = new AtividadeAcademica();
        DelAtividade.setId(DelAtividade.getId());
        DelAtividadeDAO.Delete(DelAtividade);
        return null;
    }

   
}
