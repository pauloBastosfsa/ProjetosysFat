$(".icone-anexar").hover(function() { 

$("#menu-upload").css("display", "block");

});




window.setInterval('update()', 400); // atualiza os campos do display

function update(){

var titulo = $("#input-titulo").val();
var descricao = $("#input-descricao").val();
var data = $("#input-data").val();


$(".title-mobile").text(titulo);
$(".date-mobile").text(descricao)
$(".details-mobile").text(data)

}


$("#btn-proximo").click(function() { 
	$( "#form-add" ).css("display", "none");
    $("#form-dinamico").css("display", "block");
    $("#menu-upload").css("display", "none");
  
  });



$("#btn-voltar").click(function() { 
	$( "#form-dinamico" ).css("display", "none");
    $("#form-add").css("display", "block");
  
  });




$("#btn-add").click(function(){ // quando cicar no butao de adicionar campo
		$( "#faixa" ).clone().appendTo( "#campos" );  //clona a div faixa e adiciona ela novamente na div campos
})






 $("#btn-imprimir").click(function(){
 	window.print();
 })