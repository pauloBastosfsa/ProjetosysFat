/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import Servlet.CadastroUsuarioServlet;

/**
 *
 * @author paulo
 */
public class CadastroUsuario {
   
    
    private Integer id;
    private String nome, curso, email,  senha, classe, telefone, dataNascimento, semenstre;

    public CadastroUsuario(CadastroUsuarioServlet CadUserSlt) {
        
        
    }
   
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

      public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String tipo) {
        this.classe = classe;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSemenstre() {
        return semenstre;
    }

    public void setSemenstre(String semenstre) {
        this.semenstre = semenstre;
    }

    public CadastroUsuario(String nome, String curso, String email, String senha, String classe, String telefone, String dataNascimento, String semenstre) {
        this.nome = nome;
        this.curso = curso;
        this.email = email;
        this.senha = senha;
        this.classe = classe;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.semenstre = semenstre;
    }
    
      public CadastroUsuario(Integer id, String nome, String curso, String email, String senha, String classe, String telefone, String dataNascimento, String semenstre) {
        this.id = id; 
        this.nome = nome;
        this.curso = curso;
        this.email = email;
        this.senha = senha;
        this.classe = classe;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.semenstre = semenstre;
    }
      
      public CadastroUsuario(Integer id, String nome, String curso, String email, String classe, String telefone, String dataNascimento, String semenstre) {
        this.id = id; 
        this.nome = nome;
        this.curso = curso;
        this.email = email;
        this.classe = classe;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.semenstre = semenstre;
    }
    
     public CadastroUsuario() {
        
    }
   
}
