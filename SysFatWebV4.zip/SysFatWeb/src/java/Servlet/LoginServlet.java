package Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Login;
import DAO.LoginDAO;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author murilo
 */

@WebServlet(name="login", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
       
    public String usuario, senha, Classe;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("html;charset=UTF-8");
        // joga usuario e senha nas strings
        usuario = request.getParameter("login");
        senha = request.getParameter("senha");
        Classe = request.getParameter("classe");
        // instancia o objeto login que vai ser usado na DAO
        Login login = new Login(usuario, senha, Classe);
        login.setUsuario(usuario);
        login.setSenha(senha);
        login.setClasse(Classe);
        // define a pagina de retorno como null
        String pagina = null;
        // chama a dao que verifica o login no banco e retorna se é administrador ou não
        //   Login(login);
        response.setContentType("html;charset=UTF-8");
        if (usuario.equals(login.getUsuario()) && senha.equals(login.getSenha())) {
            HttpSession sessao = request.getSession();
            sessao.setAttribute("login", usuario);
            sessao.setAttribute("permissao", login.getClasse());
            

        } else if (usuario.equals(login.getUsuario()) && senha.equals(login.getSenha())) {
            HttpSession sessao = request.getSession();
            sessao.setAttribute("login", usuario);
            sessao.setAttribute("permissao", login.getClasse());
            pagina = "UsuarioLogado.jsp";
            response.sendRedirect(pagina);

        } else if (usuario.equals(login.getUsuario()) && senha.equals(login.getSenha())) {
            HttpSession sessao = request.getSession();
            sessao.setAttribute("login", usuario);
            sessao.setAttribute("permissao", login.getClasse());
            pagina = "UsuarioLogado.jsp";
            response.sendRedirect(pagina);

        } else {
           // pagina = "UsuarioLogado.jsp";
           // response.sendRedirect(pagina);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            
        try {
            processRequest(request, response);
            List<Login> logins = new ArrayList();
            request.setAttribute("listaFrancis", logins);
            RequestDispatcher dispatcher = request.getRequestDispatcher("UsuarioLogado.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            
        
            System.out.println(request.getParameter("login"));
        
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
