/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.AtividadeAcademicaDetalDAO;
import java.sql.ResultSet;
import model.AtividadeAcademicaDetalhe;

/**
 *
 * @author paulo
 */
public class AtividadeAcademicaDetalheCTRL {

    public static ResultSet Insert() {
        AtividadeAcademicaDetalDAO CadAtvDetDAO = new AtividadeAcademicaDetalDAO();
        AtividadeAcademicaDetalhe CadCadDet = new AtividadeAcademicaDetalhe();
        CadAtvDetDAO.Insert(CadCadDet);
        return null;
    }

    public static ResultSet Update() {
        AtividadeAcademicaDetalDAO UpUAtvDetDAO = new AtividadeAcademicaDetalDAO();
        AtividadeAcademicaDetalhe UpUAtvDet = new AtividadeAcademicaDetalhe();
        UpUAtvDet.setId(UpUAtvDet.getId());
        UpUAtvDetDAO.Update(UpUAtvDet);
        return null;

    }

    public static Readable Delete() {
        AtividadeAcademicaDetalDAO DelAtvDetDAO = new AtividadeAcademicaDetalDAO();
        AtividadeAcademicaDetalhe DelAtvDel = new AtividadeAcademicaDetalhe();
        DelAtvDel.setId(DelAtvDel.getId());
        DelAtvDetDAO.Delete(DelAtvDel);
        return null;
    }

}
