/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.CadastroUsuarioDAO;
import Servlet.CadastroUsuarioServlet;
import java.sql.ResultSet;
import java.util.List;
import model.CadastroUsuario;

/**
 *
 * @author paulo
 */
public class CadastroUsuarioCTRL {

   
    
    public static ResultSet select() {
        CadastroUsuarioDAO CadUserDAO = new CadastroUsuarioDAO();
        List<CadastroUsuario> ListaUser = CadUserDAO.Select();
        System.out.println(ListaUser);
        return (ResultSet) ListaUser;
}
    
     public static ResultSet Insert(CadastroUsuario CadUser) {
        CadastroUsuarioDAO CadUsuarioDAO = new CadastroUsuarioDAO();
        CadUsuarioDAO.Insert(CadUser);
        return null;
    }

    public static ResultSet Update(CadastroUsuario CadUpUser) {
        CadastroUsuarioDAO UpUsuarioDAO = new CadastroUsuarioDAO();
        CadUpUser.setId(CadUpUser.getId());
        UpUsuarioDAO.Update(CadUpUser);
        return null;

    }

    public static ResultSet Delete(CadastroUsuario CadUserDel) {
        CadastroUsuarioDAO DelUsuarioDAO = new CadastroUsuarioDAO();
        CadUserDel.setId(CadUserDel.getId());
        DelUsuarioDAO.Delete(CadUserDel);
        return null;
    }



}
