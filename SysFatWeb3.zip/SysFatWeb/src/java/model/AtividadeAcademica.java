/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author paulo
 */
public class AtividadeAcademica {

    private Integer id;
    private String tipoAtividade, descricao, anexo, dataEvento;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipoAtividade() {
        return tipoAtividade;
    }

    public void setTipoAtividade(String tipoAtividade) {
        this.tipoAtividade = tipoAtividade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getAnexo() {
        return anexo;
    }

    public void setAnexo(String anexo) {
        this.anexo = anexo;
    }

    public String getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(String dataEvento) {
        this.dataEvento = dataEvento;
    }

    public AtividadeAcademica(String tipoAtividade, String descricao, String anexo, String dataEvento) {
        this.tipoAtividade = tipoAtividade;
        this.descricao = descricao;
        this.anexo = anexo;
        this.dataEvento = dataEvento;
    }

    public AtividadeAcademica(Integer id, String tipoAtividade, String descricao, String anexo, String dataEvento) {
        this.id = id;
        this.tipoAtividade = tipoAtividade;
        this.descricao = descricao;
        this.anexo = anexo;
        this.dataEvento = dataEvento;
    }
    public AtividadeAcademica() {
        
    }
}
