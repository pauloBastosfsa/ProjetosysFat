package Connecta;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Connecta {

    final private String driver = "org.postgresql.Driver";
    final private String url = "jdbc:postgresql://127.0.0.1:5439/SysFat";
    final private String usuario = "postgres";
    final private String senha = "@system15";

    Connection conn;

    public Connection conecta() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(null, "não encontrado! \n Erro:");
            System.out.println("Driver não encontrado!");
        }
        try {
            conn = DriverManager.getConnection(url, usuario, senha);
            //Conseguiu conectar...  
            // JOptionPane.showMessageDialog(null, "Conectado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Não foi possivel conectar");
        }
        return conn;
    }

    public Connection getCon() {
        return conn;
    }

    public void setCon(Connection con) {
        this.conn = con;
    }

    public void desconecta() {
        try {
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar a conexão!\n" + ex.getMessage());
        }
    }

}
