var $doc = $('html, body');
$('a').click(function() {   // quando clicar em qualquer tag que seja "a" (links)

	$("#box-adicionar-atividade").css("display", "block"); //mostra a parte de adicionar

    $doc.animate({ // esse metodo vai animar o movimento
        scrollTop: $( $.attr(this, 'href') ).offset().top // pega o valor que esta no href da tag "a" que foi clicado e direciona pra ancora lentamente
    }, 500); // tempo em milissegundos
    return false;  // 
});





