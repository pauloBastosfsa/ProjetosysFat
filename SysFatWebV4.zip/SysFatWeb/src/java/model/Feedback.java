/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author paulo
 */
public class Feedback {
    
    private Integer id, idAtividadeAcademica, idusuario;
    private String feedBack, dataFeedBack;

    public Feedback() {
       
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdAtividadeAcademica() {
        return idAtividadeAcademica;
    }

    public void setIdAtividadeAcademica(Integer idAtividadeAcademica) {
        this.idAtividadeAcademica = idAtividadeAcademica;
    }

    public String getFeedBack() {
        return feedBack;
    }

    public void setFeedBack(String feedBack) {
        this.feedBack = feedBack;
    }

    public Integer getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(Integer idusuario) {
        this.idusuario = idusuario;
    }

    public String getDataFeedBack() {
        return dataFeedBack;
    }

    public void setDataFeedBack(String dataFeedBack) {
        this.dataFeedBack = dataFeedBack;
    }

    public Feedback( Integer idusuario, Integer idAtividadeAcademica, String feedBack) {
        this.idusuario = idusuario;
        this.idAtividadeAcademica = idAtividadeAcademica;
        this.feedBack = feedBack;
    }

    public Feedback(Integer id) {
        this.id = id;
    }
    
}
