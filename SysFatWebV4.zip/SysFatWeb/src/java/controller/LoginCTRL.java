/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.LoginDAO;
import java.sql.SQLException;
import model.Login;

/**
 *
 * @author Usuario
 */
public class LoginCTRL {
    
    public Readable select(Login Userlogin) throws SQLException{
        LoginDAO login = new LoginDAO();
        login.select(Userlogin);
        return select(Userlogin);
    }
           
    
}
