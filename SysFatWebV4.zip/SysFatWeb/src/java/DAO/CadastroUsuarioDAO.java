package DAO;

import Connecta.Connecta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.CadastroUsuario;

public class CadastroUsuarioDAO {

    public Connecta connecta;
    private ResultSet rs;
    private String SQL, msg;

    public CadastroUsuarioDAO() {
        this.connecta = new Connecta();
    }

    public List<CadastroUsuario> Select() {
        List<CadastroUsuario> listaUser = new ArrayList<CadastroUsuario>();
        SQL = "select * from usuario order by id";

        try {

            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                
                Integer id = rs.getInt("id");
                String nome = rs.getString("nome");
                String curso = rs.getString("curso");
                String emanil = rs.getString("email");
                String classe = rs.getString("classe");
                String telefone = rs.getString("telefone");
                String data_nascimento = rs.getString("data_nascimento");
                String semestre = rs.getString("semestre");
                CadastroUsuario Users = new CadastroUsuario(id, nome, curso, emanil, classe, telefone, data_nascimento, semestre);
                Users.setId(id);
                listaUser.add(Users);
            }
            
            ps.close();
            return listaUser;

        } catch (SQLException ex) {
            System.err.println("Erro ao tentar executar a consulta" + ex.getMessage());
        }
         return (List<CadastroUsuario>) rs;
       //connecta.desconecta();
      
    }

    public void Insert(CadastroUsuario CadUser) {

        SQL = "insert into usuario (nome, curso, email, senha, classe, telefone, data_nascimento, semestre) values (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);

            ps.setString(1, CadUser.getNome());
            ps.setString(2, CadUser.getCurso());
            ps.setString(3, CadUser.getEmail());
            ps.setString(4, CadUser.getSenha());
            ps.setString(5, CadUser.getClasse());
            ps.setString(6, CadUser.getTelefone());
            ps.setString(7, CadUser.getDataNascimento());
            ps.setString(8, CadUser.getSemenstre());

            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
                      
        }

    }

    public ResultSet Update(CadastroUsuario UpUser) {

        SQL = "Update usuario set nome = ?, curso = ?, email = ?, senha = ?,  classe = ?, telefone = ?, data_nascimento = ?, semestre = ? where id = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);

            ps.setString(1, UpUser.getNome());
            ps.setString(2, UpUser.getCurso());
            ps.setString(3, UpUser.getEmail());
            ps.setString(4, UpUser.getSenha());
            ps.setString(5, UpUser.getClasse());
            ps.setString(6, UpUser.getTelefone());
            ps.setString(7, UpUser.getDataNascimento());
            ps.setString(8, UpUser.getSemenstre());
            ps.setInt(9, UpUser.getId());

            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }

    public ResultSet Delete(CadastroUsuario DelUser) {

        SQL = "delete from usuario where id = ?";

        try {
            connecta.conecta();
            PreparedStatement ps = connecta.getCon().prepareStatement(SQL);
            // rs = ps.executeQuery();

            ps.setInt(1, DelUser.getId());
            ps.execute();
            ps.close();
            connecta.desconecta();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return rs;
    }

}
