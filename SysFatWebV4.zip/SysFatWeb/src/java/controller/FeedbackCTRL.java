/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.FeedbackDAO;
import java.sql.ResultSet;
import model.Feedback;

/**
 *
 * @author paulo
 */
public class FeedbackCTRL {

    public static ResultSet Insert() {
        FeedbackDAO FeedDAO = new FeedbackDAO();
        Feedback Feed = new Feedback();
        FeedDAO.Insert(Feed);
        return null;
    }

    public static ResultSet Delete() {
        FeedbackDAO DelFeedDAO = new FeedbackDAO();
        Feedback DelFeed = new Feedback();
        DelFeedDAO.Delete(DelFeed);
        return null;
    }

    public static ResultSet select(Feedback Selfeed) {
        FeedbackDAO SelfeedDAO = new FeedbackDAO();
        SelfeedDAO.select(Selfeed);
        return null;

    }

}
